#!/bin/bash
# Hardened user data script (Apache/Nginx selectable)
