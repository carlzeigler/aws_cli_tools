---
name: Feature request
about: Suggest an idea for this project
title: "[FEATURE] "
labels: enhancement
assignees: ''
---

**Describe the feature you'd like**
A clear and concise description of the feature.

**Why is this feature needed?**
Explain the value or use case for this feature.

**Additional context**
Add any other context or examples here.
