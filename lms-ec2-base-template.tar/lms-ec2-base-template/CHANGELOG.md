# Changelog

## [1.0.0] - 2025-07-31
- Initial release.
- Hardened RHEL 8 launch template with Apache/Nginx toggle.
- Hostname, domain, and web server configurable via EC2 tags.
- Optional CloudWatch logging support.
