#!/bin/bash
# Hardened user data script with CloudWatch logging
