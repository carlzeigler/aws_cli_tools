#!/bin/bash
# Create launch template script
